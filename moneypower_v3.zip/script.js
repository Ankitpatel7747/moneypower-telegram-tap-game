// ================= CONFIG =================
const SUPABASE_URL = "https://vmvymoskytpjxeyjsyza.supabase.co";   // <-- paste your Supabase URL
const SUPABASE_ANON_KEY = "sb_publishable_sAYkfj4KQcdnKvMMAcxysQ_1JQk4GJm";                 // <-- paste your anon public key
const ADSGRAM_BLOCK_ID = "46964";
const LINKS = {
  task_yt: "https://youtube.com/@moneypower-n2x",
  task_insta: "https://www.instagram.com/moneypowermpower_token",
  task_tg: "https://t.me/o8gbqwTP39mNDJl",
};
const LAUNCH = new Date("2026-10-03T00:00:00Z").getTime();
const DAY = 86400000;
const OFFLINE_CAP_HOURS = 3;

// ================= STATE =================
const tg = window.Telegram?.WebApp;
tg?.ready(); tg?.expand();
const sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);

const S = {
  telegram_id: "guest", created_at: new Date().toISOString(), display_name: "Player1234",
  tokens_earns: 0, tap_power: 1, profit_per_hour: 0, pph_level: 0, wallet_address: null,
  task_yt: false, task_insta: false, task_tg: false, ads_count: 0, referrals_count: 0,
  last_claim: new Date().toISOString(),
};
// Local-only (not in the 14 DB columns)
let L = { max_energy: 500, energy: 500, recharge_speed: 1, energy_cost: 10000, rec_cost: 2200 };

const $ = (id) => document.getElementById(id);
const fmt = (n) => Math.floor(n).toLocaleString();
const toast = (m) => { const t = $("toast"); t.textContent = m; t.style.display = "block"; clearTimeout(t._h); t._h = setTimeout(() => (t.style.display = "none"), 2500); };
const pphCost = () => 2500 * 2 ** S.pph_level;
const saveLocal = () => localStorage.setItem("mp_local_" + S.telegram_id, JSON.stringify(L));

// ================= SUPABASE =================
async function loadUser() {
  const u = tg?.initDataUnsafe?.user;
  if (u) {
    S.telegram_id = String(u.id);
    S.display_name = `${u.first_name || ""}${u.last_name ? " " + u.last_name : ""}`.trim() + "1234";
    if (u.photo_url) $("avatar").src = u.photo_url;
  }
  if (!$("avatar").src) $("avatar").src = "logo.png";
  const saved = localStorage.getItem("mp_local_" + S.telegram_id);
  if (saved) L = { ...L, ...JSON.parse(saved) };

  try {
    const { data, error } = await sb.from("users").select("*").eq("telegram_id", S.telegram_id).maybeSingle();
    if (error) throw error;
    if (data) {
      const keepName = data.display_name || S.display_name; // permanent name
      Object.assign(S, data, { display_name: keepName });
    } else {
      await sb.from("users").upsert(S, { onConflict: "telegram_id" });
    }
  } catch (e) { console.warn("Supabase load failed:", e.message); }

  // Offline mining, capped at 3 hours
  const hrs = Math.min((Date.now() - new Date(S.last_claim).getTime()) / 3600000, OFFLINE_CAP_HOURS);
  const earned = Math.floor(hrs * S.profit_per_hour);
  if (earned > 0) { S.tokens_earns += earned; toast(`⛏️ Offline mining: +${fmt(earned)} MP`); }
  // Energy regenerated offline
  const secs = (Date.now() - new Date(S.last_claim).getTime()) / 1000;
  L.energy = Math.min(L.max_energy, L.energy + secs * L.recharge_speed);
  S.last_claim = new Date().toISOString();
  saveNow();
}

let saveTimer = null;
function saveSoon() { clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, 1200); } // 1.2s debounce
async function saveNow() {
  saveLocal();
  S.last_claim = new Date().toISOString();
  try { await sb.from("users").upsert({ ...S, tokens_earns: Math.floor(S.tokens_earns) }, { onConflict: "telegram_id" }); }
  catch (e) { console.warn("save failed", e.message); }
}

// ================= UI =================
function render() {
  $("dname").textContent = S.display_name;
  $("tokens").textContent = fmt(S.tokens_earns);
  $("sTap").textContent = S.tap_power;
  $("sPph").textContent = fmt(S.profit_per_hour);
  $("sRec").textContent = L.recharge_speed.toFixed(1);
  $("eTxt").textContent = `${fmt(L.energy)}/${fmt(L.max_energy)}`;
  $("eBar").style.width = (L.energy / L.max_energy) * 100 + "%";
  $("adsCnt").textContent = S.ads_count;

  const eMax = L.max_energy >= 10500, rMax = L.recharge_speed >= 19;
  $("dEnergy").textContent = eMax ? "MAX 10,500" : `${fmt(L.max_energy)} → ${fmt(L.max_energy + 500)}`;
  $("uEnergy").textContent = eMax ? "MAX" : fmt(L.energy_cost);
  $("uEnergy").disabled = eMax || S.tokens_earns < L.energy_cost;
  $("dRec").textContent = rMax ? "MAX 19/s" : `${L.recharge_speed.toFixed(1)}/s → ${Math.min(19, L.recharge_speed + 1.2).toFixed(1)}/s`;
  $("uRec").textContent = rMax ? "MAX" : fmt(L.rec_cost);
  $("uRec").disabled = rMax || S.tokens_earns < L.rec_cost;
  $("dPph").textContent = `Lvl ${S.pph_level} · +150 / hour`;
  $("uPph").textContent = fmt(pphCost());
  $("uPph").disabled = S.tokens_earns < pphCost();

  document.querySelectorAll(".task").forEach((b) => { if (S[b.dataset.k]) { b.disabled = true; b.textContent = "✓ Done"; } });
  renderWallet();
}

// ================= TAP =================
$("tapBtn").addEventListener("pointerdown", (e) => {
  if (L.energy < S.tap_power) { toast("⚡ Not enough energy"); return; }
  L.energy -= S.tap_power;
  S.tokens_earns += S.tap_power;
  tg?.HapticFeedback?.impactOccurred("light");
  const f = document.createElement("div");
  f.className = "float"; f.textContent = "+" + S.tap_power;
  f.style.left = e.clientX - 10 + "px"; f.style.top = e.clientY - 20 + "px";
  document.body.appendChild(f); setTimeout(() => f.remove(), 800);
  render(); saveSoon();
});

// Energy recharge + live PPH every second
setInterval(() => {
  L.energy = Math.min(L.max_energy, L.energy + L.recharge_speed);
  S.tokens_earns += S.profit_per_hour / 3600;
  render();
}, 1000);
setInterval(saveNow, 15000);

// ================= UPGRADES =================
$("uEnergy").onclick = () => {
  if (L.max_energy >= 10500 || S.tokens_earns < L.energy_cost) return;
  S.tokens_earns -= L.energy_cost; L.max_energy = Math.min(10500, L.max_energy + 500); L.energy_cost *= 2;
  toast("Max energy upgraded!"); render(); saveNow();
};
$("uRec").onclick = () => {
  if (L.recharge_speed >= 19 || S.tokens_earns < L.rec_cost) return;
  S.tokens_earns -= L.rec_cost; L.recharge_speed = Math.min(19, +(L.recharge_speed + 1.2).toFixed(1)); L.rec_cost = Math.round(L.rec_cost * 2.2);
  toast("Recharge speed upgraded!"); render(); saveNow();
};
$("uPph").onclick = () => {
  const c = pphCost(); if (S.tokens_earns < c) return;
  S.tokens_earns -= c; S.pph_level++; S.profit_per_hour += 150;
  toast("+150 profit per hour!"); render(); saveNow();
};

// ================= TASKS =================
document.querySelectorAll(".task").forEach((b) => (b.onclick = () => {
  const k = b.dataset.k; if (S[k]) return;
  const url = LINKS[k];
  if (k === "task_tg" && tg?.openTelegramLink) tg.openTelegramLink(url);
  else if (tg?.openLink) tg.openLink(url); else window.open(url, "_blank");
  b.disabled = true; let n = 3; b.textContent = `Verifying ${n}…`;
  const iv = setInterval(() => {
    n--; if (n > 0) { b.textContent = `Verifying ${n}…`; return; }
    clearInterval(iv); S[k] = true; S.tokens_earns += 5000;
    toast("✅ Task verified! +5,000 MP"); render(); saveNow();
  }, 1000);
}));

// ================= ADSGRAM =================
let AdCtrl = null;
try { AdCtrl = window.Adsgram?.init({ blockId: ADSGRAM_BLOCK_ID }); } catch (e) { console.warn(e); }
$("adBtn").onclick = async () => {
  if (!AdCtrl) { toast("Ads unavailable — open inside Telegram"); return; }
  try {
    const r = await AdCtrl.show();
    if (r?.done) { S.tap_power += 3; S.ads_count++; toast("🚀 +3 Tap Power forever!"); render(); saveNow(); }
    else toast("Watch the full ad to get the reward");
  } catch { toast("Ad skipped or not available"); }
};

// ================= WALLET TIME-LOCK =================
function walletState() {
  const day = Math.floor((Date.now() - LAUNCH) / DAY) + 1; // Day 1 = launch date
  if (day <= 3) return { open: true, msg: `Testing window open (Day ${Math.max(day, 1)}/3)` };
  if (day <= 161) return { open: false, msg: `🔒 Something big is coming… unlocks in ${162 - day} days` };
  return { open: true, msg: "🔓 Wallet connection is LIVE" };
}
function renderWallet() {
  const w = walletState();
  $("wTxt").textContent = S.wallet_address ? `Connected: ${S.wallet_address.slice(0, 6)}…${S.wallet_address.slice(-4)}` : w.msg;
  $("wBtn").disabled = !w.open; $("wBtn").textContent = S.wallet_address ? "Change" : w.open ? "👻 Connect Phantom" : "Locked";
}
// ---------- Phantom (Solana) connect ----------
const B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function b58enc(bytes) {
  let n = 0n; for (const b of bytes) n = n * 256n + BigInt(b);
  let out = ""; while (n > 0n) { out = B58[Number(n % 58n)] + out; n /= 58n; }
  for (const b of bytes) { if (b === 0) out = "1" + out; else break; }
  return out;
}
function b58dec(str) {
  let n = 0n; for (const c of str) { const i = B58.indexOf(c); if (i < 0) throw new Error("bad b58"); n = n * 58n + BigInt(i); }
  const bytes = []; while (n > 0n) { bytes.unshift(Number(n % 256n)); n /= 256n; }
  for (const c of str) { if (c === "1") bytes.unshift(0); else break; }
  return new Uint8Array(bytes);
}
async function saveWallet(addr) {
  S.wallet_address = addr; render(); await saveNow(); toast("👻 Phantom wallet connected");
}
async function connectPhantom() {
  // 1) Inside Phantom's in-app browser or desktop with extension
  const p = window.phantom?.solana || (window.solana?.isPhantom ? window.solana : null);
  if (p) {
    try { const r = await p.connect(); return saveWallet(r.publicKey.toString()); }
    catch { return toast("Connection cancelled"); }
  }
  // 2) Mobile / Telegram: open the Phantom app via deeplink
  const kp = nacl.box.keyPair();
  const back = new URL(location.origin + location.pathname);
  back.searchParams.set("pc", "1");
  back.searchParams.set("tid", S.telegram_id);
  back.searchParams.set("sk", b58enc(kp.secretKey));
  const url = "https://phantom.app/ul/v1/connect?" + new URLSearchParams({
    app_url: location.origin, dapp_encryption_public_key: b58enc(kp.publicKey),
    redirect_link: back.toString(), cluster: "mainnet-beta",
  });
  saveNow();
  if (tg?.openLink) tg.openLink(url); else location.href = url;
}
// Handles the return trip from the Phantom app
async function handlePhantomReturn() {
  const q = new URLSearchParams(location.search);
  if (q.get("pc") !== "1") return false;
  document.body.innerHTML = '<div style="padding:40px;text-align:center;font-family:Sora,sans-serif"><img src="logo.png" style="width:120px"><h2 id="pm" style="margin-top:20px">Connecting wallet…</h2></div>';
  const msg = (t) => (document.getElementById("pm").innerHTML = t);
  if (q.get("errorCode")) return msg("❌ Connection cancelled in Phantom."), true;
  try {
    const box = nacl.box.open(b58dec(q.get("data")), b58dec(q.get("nonce")), b58dec(q.get("phantom_encryption_public_key")), b58dec(q.get("sk")));
    if (!box) throw new Error("decrypt failed");
    const addr = JSON.parse(new TextDecoder().decode(box)).public_key;
    const { error } = await sb.from("users").update({ wallet_address: addr }).eq("telegram_id", q.get("tid"));
    if (error) throw error;
    msg(`✅ Wallet connected!<br><small style="word-break:break-all">${addr}</small><br><br>Go back to Telegram and reopen MoneyPower.`);
  } catch (e) { msg("❌ Could not connect wallet: " + e.message); }
  return true;
}
$("wBtn").onclick = () => { if (walletState().open) connectPhantom(); };
// Pick up a wallet connected while the app was in the background
document.addEventListener("visibilitychange", async () => {
  if (document.hidden || S.wallet_address) return;
  const { data } = await sb.from("users").select("wallet_address").eq("telegram_id", S.telegram_id).maybeSingle();
  if (data?.wallet_address) saveWallet(data.wallet_address);
});

// ================= TABS & BOOT =================
document.querySelectorAll(".tabs button").forEach((b) => (b.onclick = () => {
  document.querySelectorAll(".tabs button").forEach((x) => x.classList.remove("on"));
  document.querySelectorAll(".panel").forEach((x) => x.classList.remove("on"));
  b.classList.add("on"); $("p-" + b.dataset.p).classList.add("on");
}));
window.addEventListener("beforeunload", saveNow);
document.addEventListener("visibilitychange", () => document.hidden && saveNow());

(async () => {
  if (await handlePhantomReturn()) return;
  const boot = loadUser();
  await new Promise((r) => setTimeout(r, 3000)); // splash exactly 3s
  await boot;
  $("splash").style.opacity = 0;
  setTimeout(() => ($("splash").style.display = "none"), 500);
  $("app").style.display = "block";
  render();
})();
