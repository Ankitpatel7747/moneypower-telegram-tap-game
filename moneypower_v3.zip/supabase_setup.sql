-- Run this in Supabase > SQL Editor
create table if not exists public.users (
  telegram_id text primary key,
  created_at timestamptz default now(),
  display_name text,
  tokens_earns numeric default 0,
  tap_power int8 default 1,
  profit_per_hour int8 default 0,
  pph_level int8 default 0,
  wallet_address text,
  task_yt boolean default false,
  task_insta boolean default false,
  task_tg boolean default false,
  ads_count integer default 0,
  referrals_count integer default 0,
  last_claim timestamptz default now()
);
grant select, insert, update on public.users to anon;
alter table public.users enable row level security;
create policy "game read" on public.users for select to anon using (true);
create policy "game insert" on public.users for insert to anon with check (true);
create policy "game update" on public.users for update to anon using (true);
